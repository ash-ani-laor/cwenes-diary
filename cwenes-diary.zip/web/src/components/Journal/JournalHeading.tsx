// web/src/components/Journal/JournalHeading.tsx
import React from 'react'

export function JournalHeading() {
  return <h1 className="text-2xl font-bold">Дневник</h1>
}
