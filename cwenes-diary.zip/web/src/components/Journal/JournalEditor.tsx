import React, { useState } from 'react'

import MDEditor from '@uiw/react-md-editor'

const JournalEditor = ({ post = {}, onClose }) => {
  const [title, setTitle] = useState(post.title || '')
  const [content, setContent] = useState(post.content || '')

  const handleSave = () => {
    // todo: логика сохранения
    alert('Пост сохранён!')
    onClose()
  }

  return (
    <div className="flex min-h-0 w-full max-w-full flex-1 flex-col rounded bg-white p-4 shadow-md">
      <input
        className="mb-4 w-full rounded border px-3 py-2 text-xl font-semibold"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Заголовок"
      />
      <div className="flex min-h-0 flex-1 flex-col">
        <MDEditor
          className="min-h-0 flex-1"
          value={content}
          onChange={setContent}
          textareaProps={{
            placeholder: 'Введите текст записи с поддержкой Markdown...',
          }}
        />
      </div>
      <div className="mt-4 flex justify-end gap-2">
        <button
          className="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-800"
          onClick={handleSave}
        >
          Сохранить
        </button>
        <button
          className="rounded bg-gray-300 px-4 py-2 hover:bg-gray-400"
          onClick={onClose}
        >
          Отмена
        </button>
      </div>
    </div>
  )
}

export default JournalEditor
