import { useState } from 'react'

// import { Alert } from 'src/components/ui/Alert'
// import { Button } from 'src/components/ui/Button'
// import { Card } from 'src/components/ui/Card'
// import { Dialog, DialogTrigger, DialogContent } from 'src/components/ui/Dialog'
// import { FloatingWindow } from 'src/components/ui/FloatingWindow'
// import { StageBox } from 'src/components/ui/StageBox'

const HomePage = () => {
  // const [showWin, setShowWin] = useState(true)
  // const [open, setOpen] = useState(false)

  return <></>
}

export default HomePage
