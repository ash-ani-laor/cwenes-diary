/**
 * web\src\constants\draftTypes.js
 */

export const DraftTypes = {
  PROTOCOL: 'protocol',
  POST: 'post',
}
