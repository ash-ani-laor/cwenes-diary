/**
 * web\src\constants\protocolCanvas.js
 */
export const PROTOCOL_CANVAS_WIDTH = 600
export const PROTOCOL_CANVAS_HEIGHT = 400
export const TILE_SIZE = 32
